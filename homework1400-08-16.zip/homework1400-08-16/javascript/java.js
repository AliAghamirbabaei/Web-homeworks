function changeContant() {
 document.getElementById("header-text").innerHTML = "Javascript Header";
}

function changeAttribute() {
 document.getElementsByTagName("img")[0].setAttribute("src", "images/v3_9.png");
}

function changeStyle() {
 document.getElementById("footer-text").style.opacity = "10%";
}

function hide() {
  var myImage = document.getElementsByTagName("img")[1];
  myImage.style.opacity = "0%";
}

function show() {
  var myImage = document.getElementsByTagName("img")[1];
  myImage.style.opacity = "100%";
}
